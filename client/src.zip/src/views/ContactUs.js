import React from "react";
import Form from "./components/Form";

function ContactUs() {

  return (
    <div>
      <div className="row">
        <div className="col">
            <Form
            />
      </div>
    </div>
  </div>
  );
}
export default ContactUs;