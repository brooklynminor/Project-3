import React from "react";

function AboutUs(props) {
    return (
        <div>
            About Us
        </div>
    )
}
export default AboutUs