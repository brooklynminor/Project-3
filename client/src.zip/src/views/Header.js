import React from 'react'

function Header(){
return(
<header className="App-header">
{/* <a href="#" class="col-sm-8 fs-1">Pet Hotel</a>
<a href="#" class="col-sm-2 ml-2 mr-1">Contact</a>
<a href="#" class="col-sm-2 ml-1">About Us</a> */}

</header>
)
}
export default Header;