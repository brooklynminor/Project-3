import React from "react";
import Calendar from "./components/Calendar";

function Schedule(props) {
  return (
    <div>
      <div className="row">
        <div className="col">
        <Calendar />
      </div>
    </div>
  </div>
  );
}
export default Schedule;
